# Estado de producción V11

[OK] Proyecto Android
[OK] Application ID
[OK] Target SDK 36
[OK] Separación de sesión/roles
[OK] Contrato de backend
[OK] Estructura de datos
[OK] Navegación de la app
[PENDIENTE] Proyecto backend real
[PENDIENTE] Autenticación real
[PENDIENTE] RLS real desplegado
[PENDIENTE] Storage privado
[PENDIENTE] Notificaciones push
[PENDIENTE] Firma release
[PENDIENTE] APK release
[PENDIENTE] Publicación/hosting del APK

No usar datos reales hasta completar los puntos de seguridad pendientes.
