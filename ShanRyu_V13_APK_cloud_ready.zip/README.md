# Shanryu Android V13

Proyecto Android de Escuela de Karate y Judo Shanryu Benito Juárez.

## V13
- Pipeline GitHub Actions para generar APK automáticamente.
- Pipeline separado para APK Release firmado mediante secrets.
- Firma fuera del código fuente.
- Base backend PostgreSQL/Supabase incluida.
- App Android preparada para recibir URL y anon key del backend.

## Importante
Este paquete todavía no contiene credenciales reales ni un proyecto Supabase real. No se inventan credenciales. Para producción hay que crear el proyecto backend y cargar `backend/schema.sql`, y luego configurar `BACKEND_URL` y `BACKEND_ANON_KEY`. Nunca colocar `service_role` dentro del APK.
