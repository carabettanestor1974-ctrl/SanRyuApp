-- SHANRYU V7 — SEGURIDAD Y ACCESO
-- Ejecutar en un proyecto PostgreSQL/Supabase nuevo.
create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null check (role in ('admin','teacher','family')),
  created_at timestamptz default now()
);

create table if not exists students (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  birth_date date,
  phone text,
  email text,
  address text,
  discipline text check (discipline in ('Karate','Judo')),
  active boolean default true,
  created_at timestamptz default now()
);

create table if not exists guardians (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students(id) on delete cascade,
  profile_id uuid not null references profiles(id) on delete cascade,
  relationship text,
  unique(student_id, profile_id)
);

create table if not exists charges (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students(id) on delete cascade,
  period date not null,
  amount numeric(12,2) not null,
  due_date date not null,
  status text not null default 'pending'
    check(status in ('pending','paid','overdue')),
  paid_at timestamptz
);

create table if not exists attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students(id) on delete cascade,
  class_date date not null,
  present boolean not null,
  notes text,
  unique(student_id,class_date)
);

create table if not exists belt_history (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students(id) on delete cascade,
  belt text not null,
  awarded_on date not null,
  notes text
);

create table if not exists announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  published_at timestamptz default now(),
  published_by uuid references profiles(id)
);

create table if not exists achievements (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  title text not null,
  description text,
  event_date date,
  photo_url text
);

-- RLS
alter table profiles enable row level security;
alter table students enable row level security;
alter table guardians enable row level security;
alter table charges enable row level security;
alter table attendance enable row level security;
alter table belt_history enable row level security;
alter table announcements enable row level security;
alter table achievements enable row level security;

-- Familia: solamente alumnos vinculados a su perfil.
create policy "family reads linked students"
on students for select to authenticated
using (
  exists (
    select 1 from guardians g
    where g.student_id = students.id
      and g.profile_id = auth.uid()
  )
  or exists (
    select 1 from profiles p
    where p.id = auth.uid() and p.role in ('admin','teacher')
  )
);

create policy "family reads own links"
on guardians for select to authenticated
using (
  profile_id = auth.uid()
  or exists (
    select 1 from profiles p
    where p.id = auth.uid() and p.role in ('admin','teacher')
  )
);

create policy "family reads own charges"
on charges for select to authenticated
using (
  exists (
    select 1 from guardians g
    where g.student_id = charges.student_id
      and g.profile_id = auth.uid()
  )
  or exists (
    select 1 from profiles p
    where p.id = auth.uid() and p.role in ('admin','teacher')
  )
);

create policy "family reads own attendance"
on attendance for select to authenticated
using (
  exists (
    select 1 from guardians g
    where g.student_id = attendance.student_id
      and g.profile_id = auth.uid()
  )
  or exists (
    select 1 from profiles p
    where p.id = auth.uid() and p.role in ('admin','teacher')
  )
);

create policy "family reads own belts"
on belt_history for select to authenticated
using (
  exists (
    select 1 from guardians g
    where g.student_id = belt_history.student_id
      and g.profile_id = auth.uid()
  )
  or exists (
    select 1 from profiles p
    where p.id = auth.uid() and p.role in ('admin','teacher')
  )
);

create policy "authenticated reads announcements"
on announcements for select to authenticated
using (true);

create policy "family reads own achievements"
on achievements for select to authenticated
using (
  exists (
    select 1 from guardians g
    where g.student_id = achievements.student_id
      and g.profile_id = auth.uid()
  )
  or exists (
    select 1 from profiles p
    where p.id = auth.uid() and p.role in ('admin','teacher')
  )
);

-- En producción, las policies de INSERT/UPDATE/DELETE deben limitarse
-- explícitamente a admin/teacher. No usar service_role en el cliente.
