# Backend Shanryu V12

Infraestructura preparada para la puesta en marcha online:
1. Crear proyecto backend.
2. Ejecutar schema.sql.
3. Activar autenticación por email.
4. Crear Storage privado para fotografías.
5. Configurar RLS.
6. Desplegar la función fee-reminders.
7. Conectar AppConfig.kt.
8. Compilar release.

No se incluyen credenciales privadas.
