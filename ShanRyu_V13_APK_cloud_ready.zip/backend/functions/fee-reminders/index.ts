// Shanryu — recordatorios de cuotas.
// Esqueleto server-side. No colocar claves privadas dentro del APK.
export default async function handler() {
  return new Response(
    JSON.stringify({ok:true, message:"Recordatorios preparados para conectar al proveedor de notificaciones."}),
    {headers:{"content-type":"application/json"}}
  );
}
