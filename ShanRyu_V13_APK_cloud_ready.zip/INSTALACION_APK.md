# Distribución por APK

Una vez generado Shanryu-release.apk:
1. Subirlo a Drive o Dropbox.
2. Compartir el enlace con usuarios autorizados.
3. Descargar desde Android.
4. Autorizar la instalación desde esa fuente si Android lo solicita.
5. Instalar.

Para distribución masiva, Google Play será más cómodo para las actualizaciones.
