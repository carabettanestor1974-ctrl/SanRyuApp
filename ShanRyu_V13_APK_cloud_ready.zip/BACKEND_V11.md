# Shanryu V11 — conexión de producción

La aplicación Android ya tiene separado el contrato de backend de la interfaz.

## Flujo definitivo

Android
→ autenticación
→ backend online
→ base de datos
→ datos de alumnos/cuotas/asistencia
→ permisos por rol.

### Roles

**Administrador**
- alumnos
- familias
- cuotas
- asistencia
- cinturones
- comunicados
- logros/fotos

**Profesor**
- asistencia
- alumnos
- camino del alumno
- comunicados según permisos

**Familia**
- solamente sus alumnos vinculados
- cuotas
- asistencia
- cinturón/evolución
- comunicados
- fotografías autorizadas

## Seguridad

El APK no debe contener claves privadas ni `service_role`.
La autorización real se hace en el backend mediante autenticación + RLS.

## Próximo paso de infraestructura

Hay que crear el proyecto backend real, ejecutar el esquema SQL de V7, configurar Auth y Storage privado y luego completar `AppConfig.kt` con la URL pública y la clave pública.
