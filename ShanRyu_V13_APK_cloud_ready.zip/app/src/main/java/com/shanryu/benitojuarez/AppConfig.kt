package com.shanryu.benitojuarez

object AppConfig {
    // Se completan en la fase de despliegue. Nunca usar service_role dentro del APK.
    const val BACKEND_URL = "https://fsdwlbncaiegpggickmt.supabase.co"
    const val BACKEND_ANON_KEY = "sb_publishable_MWG2DprP4oc3ykFbDMzSYg_PEVuyRWS"
    const val APP_VERSION = "1.3.0"
}
