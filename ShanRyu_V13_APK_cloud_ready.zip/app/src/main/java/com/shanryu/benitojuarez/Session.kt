package com.shanryu.benitojuarez

data class UserSession(
    val userId: String,
    val role: Role,
    val displayName: String
)

enum class Role { ADMIN, TEACHER, FAMILY }
