package com.shanryu.benitojuarez

/**
 * Contrato de datos de Shanryu.
 *
 * La implementación concreta se conecta al backend cuando se configure
 * el proyecto de producción. Mantener este contrato separado evita
 * mezclar credenciales o lógica de servidor dentro de las pantallas.
 */
interface BackendContract {
    suspend fun signIn(email: String, password: String): UserSession
    suspend fun signOut()
    suspend fun students(): List<Student>
    suspend fun charges(): List<Charge>
    suspend fun attendance(date: String): List<AttendanceRecord>
}

data class Student(
    val id: String,
    val name: String,
    val discipline: String,
    val belt: String,
    val active: Boolean
)

data class Charge(
    val id: String,
    val studentId: String,
    val period: String,
    val amount: Double,
    val dueDate: String,
    val status: String
)

data class AttendanceRecord(
    val studentId: String,
    val date: String,
    val present: Boolean
)
