# Shanryu V12 — Plan de lanzamiento

### Backend
- Proyecto online
- Base de datos
- Auth
- RLS
- Storage privado
- Recordatorios

### Android
- Login real
- Sesión persistente
- Datos online
- Área familia
- Manejo offline

### Distribución
- Keystore de release
- APK release para Drive/Dropbox
- AAB para Google Play

El proyecto Android está preparado. La infraestructura externa requiere un proyecto/cuenta del propietario.
