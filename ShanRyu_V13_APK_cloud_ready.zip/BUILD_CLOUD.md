# Compilación en la nube

El repositorio incluye `.github/workflows/android.yml`. Al subir el proyecto a GitHub, la acción puede generar automáticamente un APK Debug como artefacto.

Para Release firmado, configurar en GitHub Actions Secrets:
- `SHANRYU_KEYSTORE_B64`
- `SHANRYU_STORE_PASSWORD`
- `SHANRYU_KEY_ALIAS`
- `SHANRYU_KEY_PASSWORD`

La clave privada debe generarse y conservarse fuera del chat. No subir el `.jks` al repositorio.
