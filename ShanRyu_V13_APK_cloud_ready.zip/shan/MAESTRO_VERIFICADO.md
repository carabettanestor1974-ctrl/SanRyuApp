# Shan Ryu — Index Maestro completo

Esta versión está preparada como aplicación móvil WebView y conserva Supabase como backend.

## Interfaz
- Portada Shan Ryu con identidad de karateka; no usa el robot de Android como icono de la app.
- Acceso Administrador y Alumno/Familia.
- Navegación móvil inferior: Inicio, Alumnos, Cuotas, Asistencia y Más.
- Formularios en ventanas inferiores (bottom sheets), evitando páginas tipo sábana.

## Módulos de gestión
- Inicio: resumen de alumnos, cuotas, asistencia y avisos.
- Alumnos: búsqueda, alta, edición y ficha individual.
- Cuotas: alumno, período, importe, vencimiento, estado y guardado en `charges`.
- Asistencia: fecha, alumno, grupo, presente/ausente, observaciones y guardado/upsert en `attendance`.
- Camino: alumno, cinturón, fecha, observaciones e historial en `belt_history`.
- Familia: alumno, perfil de adulto responsable y relación en `adultos_responsables`.
- Logros: alumno, título, descripción, fecha y URL de foto en `logros`.
- Anuncios: título, contenido y publicación en `anuncios`.

## Android
- Icono de aplicación propio con silueta de karateka.
- Versión 1.4.0 / versionCode 14.
