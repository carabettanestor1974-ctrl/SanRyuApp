# Compilación

1. Abrir la carpeta `ShanRyu_Android_V10` en Android Studio.
2. Esperar la sincronización de Gradle.
3. Seleccionar `app`.
4. Ejecutar `Build > Generate App Bundles or APKs > Generate APKs`.
5. El APK de debug aparecerá normalmente en `app/build/outputs/apk/debug/`.

Para una versión pública/final:
- configurar firma de release;
- conectar backend;
- activar autenticación;
- revisar permisos y privacidad;
- generar AAB para Google Play y APK para distribución directa.
